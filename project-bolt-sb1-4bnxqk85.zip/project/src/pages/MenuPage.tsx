import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  QrCode, 
  Phone, 
  Clock, 
  MapPin, 
  Star, 
  Bell,
  Utensils,
  Coffee,
  Soup,
  IceCream,
  Wine,
  AlertTriangle,
  Smartphone
} from 'lucide-react';
import toast from 'react-hot-toast';

interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: number;
  category: string;
  image?: string;
  allergens?: string[];
  available: boolean;
  popular?: boolean;
}

interface Restaurant {
  id: string;
  name: string;
  description: string;
  phone: string;
  address: string;
  rating: number;
  openHours: string;
  features: {
    waiterCall: boolean;
    nfcEnabled: boolean;
    multiLanguage: boolean;
  };
}

const MenuPage = () => {
  const { restaurantId } = useParams();
  const [restaurant, setRestaurant] = useState<Restaurant | null>(null);
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [loading, setLoading] = useState(true);

  // Mock data - gerçek uygulamada API'den gelecek
  useEffect(() => {
    const mockRestaurant: Restaurant = {
      id: restaurantId || '1',
      name: 'Lezzet Durağı',
      description: 'Geleneksel Türk mutfağının en lezzetli örnekleri',
      phone: '0555 123 45 67',
      address: 'Atatürk Cad. No:123, Kadıköy/İstanbul',
      rating: 4.8,
      openHours: '09:00 - 23:00',
      features: {
        waiterCall: true,
        nfcEnabled: true,
        multiLanguage: true
      }
    };

    const mockMenuItems: MenuItem[] = [
      {
        id: '1',
        name: 'Adana Kebap',
        description: 'Özel baharatlarla hazırlanmış lezzetli Adana kebap, pilav ve salata ile',
        price: 45,
        category: 'Ana Yemek',
        allergens: ['Gluten'],
        available: true,
        popular: true
      },
      {
        id: '2',
        name: 'Mercimek Çorbası',
        description: 'Geleneksel mercimek çorbası, taze nane ve limon ile',
        price: 15,
        category: 'Çorba',
        allergens: [],
        available: true
      },
      {
        id: '3',
        name: 'Karışık Izgara',
        description: 'Adana, urfa, köfte ve tavuk şiş karışımı',
        price: 65,
        category: 'Ana Yemek',
        allergens: ['Gluten'],
        available: true,
        popular: true
      },
      {
        id: '4',
        name: 'Türk Kahvesi',
        description: 'Geleneksel Türk kahvesi, lokum ile',
        price: 12,
        category: 'İçecek',
        allergens: [],
        available: true
      },
      {
        id: '5',
        name: 'Baklava',
        description: 'Ev yapımı baklava, Antep fıstığı ile',
        price: 25,
        category: 'Tatlı',
        allergens: ['Gluten', 'Fındık'],
        available: true
      },
      {
        id: '6',
        name: 'Çoban Salata',
        description: 'Taze domates, salatalık, soğan ve maydanoz',
        price: 18,
        category: 'Salata',
        allergens: [],
        available: true
      }
    ];

    setTimeout(() => {
      setRestaurant(mockRestaurant);
      setMenuItems(mockMenuItems);
      setLoading(false);
    }, 1000);
  }, [restaurantId]);

  const categories = [
    { id: 'all', name: 'Tümü', icon: Utensils },
    { id: 'Çorba', name: 'Çorbalar', icon: Soup },
    { id: 'Ana Yemek', name: 'Ana Yemekler', icon: Utensils },
    { id: 'Salata', name: 'Salatalar', icon: Coffee },
    { id: 'Tatlı', name: 'Tatlılar', icon: IceCream },
    { id: 'İçecek', name: 'İçecekler', icon: Wine }
  ];

  const filteredItems = selectedCategory === 'all' 
    ? menuItems 
    : menuItems.filter(item => item.category === selectedCategory);

  const callWaiter = () => {
    toast.success('Garson çağrıldı! Kısa sürede yanınızda olacak.');
  };

  const getCategoryIcon = (categoryName: string) => {
    const category = categories.find(cat => cat.id === categoryName);
    return category ? category.icon : Utensils;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <QrCode className="h-12 w-12 text-blue-600 mx-auto mb-4 animate-pulse" />
          <p className="text-gray-600">Menü yükleniyor...</p>
        </div>
      </div>
    );
  }

  if (!restaurant) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-600">Restoran bulunamadı.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Restaurant Header */}
      <div className="bg-white shadow-sm">
        <div className="max-w-4xl mx-auto px-4 py-6">
          <div className="text-center">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">{restaurant.name}</h1>
            <p className="text-gray-600 mb-4">{restaurant.description}</p>
            
            <div className="flex flex-wrap justify-center items-center gap-4 text-sm text-gray-600">
              <div className="flex items-center">
                <Star className="h-4 w-4 text-yellow-400 mr-1" />
                <span>{restaurant.rating}</span>
              </div>
              <div className="flex items-center">
                <Clock className="h-4 w-4 mr-1" />
                <span>{restaurant.openHours}</span>
              </div>
              <div className="flex items-center">
                <Phone className="h-4 w-4 mr-1" />
                <span>{restaurant.phone}</span>
              </div>
            </div>

            <div className="flex items-center justify-center mt-2 text-sm text-gray-600">
              <MapPin className="h-4 w-4 mr-1" />
              <span>{restaurant.address}</span>
            </div>
          </div>
        </div>
      </div>

      {/* NFC/QR Info Banner */}
      <div className="bg-blue-50 border-b border-blue-100">
        <div className="max-w-4xl mx-auto px-4 py-3">
          <div className="flex items-center justify-center text-sm text-blue-700">
            <Smartphone className="h-4 w-4 mr-2" />
            <span>Bu menüye NFC veya QR kod ile erişiyorsunuz</span>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-6">
        {/* Waiter Call Button */}
        {restaurant.features.waiterCall && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-6"
          >
            <button
              onClick={callWaiter}
              className="w-full bg-green-600 text-white py-4 px-6 rounded-xl font-semibold text-lg hover:bg-green-700 transition-colors flex items-center justify-center shadow-lg"
            >
              <Bell className="h-6 w-6 mr-2" />
              Garson Çağır
            </button>
          </motion.div>
        )}

        {/* Category Filter */}
        <div className="mb-6">
          <div className="flex overflow-x-auto pb-2 space-x-2">
            {categories.map((category) => {
              const IconComponent = category.icon;
              return (
                <button
                  key={category.id}
                  onClick={() => setSelectedCategory(category.id)}
                  className={`flex-shrink-0 flex items-center px-4 py-2 rounded-lg font-medium transition-colors ${
                    selectedCategory === category.id
                      ? 'bg-blue-600 text-white'
                      : 'bg-white text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  <IconComponent className="h-4 w-4 mr-2" />
                  {category.name}
                </button>
              );
            })}
          </div>
        </div>

        {/* Menu Items */}
        <div className="space-y-4">
          {filteredItems.map((item, index) => {
            const CategoryIcon = getCategoryIcon(item.category);
            return (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className={`bg-white rounded-xl shadow-sm p-6 border border-gray-100 ${
                  !item.available ? 'opacity-60' : ''
                } ${item.popular ? 'ring-2 ring-yellow-200' : ''}`}
              >
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <div className="flex items-center mb-2">
                      <CategoryIcon className="h-5 w-5 text-gray-400 mr-2" />
                      {item.popular && (
                        <span className="bg-yellow-100 text-yellow-800 text-xs px-2 py-1 rounded-full mr-2">
                          Popüler
                        </span>
                      )}
                      <span className="text-sm text-gray-500">{item.category}</span>
                    </div>
                    
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">
                      {item.name}
                    </h3>
                    
                    <p className="text-gray-600 mb-3 leading-relaxed">
                      {item.description}
                    </p>

                    {item.allergens && item.allergens.length > 0 && (
                      <div className="flex items-center mb-3">
                        <AlertTriangle className="h-4 w-4 text-orange-500 mr-2" />
                        <span className="text-sm text-orange-600">
                          Alerjenler: {item.allergens.join(', ')}
                        </span>
                      </div>
                    )}

                    {!item.available && (
                      <div className="text-red-600 text-sm font-medium">
                        Şu anda mevcut değil
                      </div>
                    )}
                  </div>

                  <div className="ml-6 text-right">
                    <div className="text-2xl font-bold text-gray-900">
                      ₺{item.price}
                    </div>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>

        {filteredItems.length === 0 && (
          <div className="text-center py-12">
            <Utensils className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600">Bu kategoride ürün bulunamadı.</p>
          </div>
        )}

        {/* Footer */}
        <div className="mt-12 text-center text-sm text-gray-500 border-t border-gray-200 pt-6">
          <p>Bu menü NFCMenu ile oluşturulmuştur</p>
          <p className="mt-1">Daha fazla bilgi için: nfcmenu.com</p>
        </div>
      </div>
    </div>
  );
};

export default MenuPage;