import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Plus, Edit, Trash2, Save, X, Upload, Image as ImageIcon } from 'lucide-react';
import { useRestaurantStore } from '../stores/useRestaurantStore';
import { MenuItem } from '../types';
import { useAuth } from '../contexts/AuthContext';
import toast from 'react-hot-toast';

interface MenuItemManagerProps {
  restaurantId: string;
}

const MenuItemManager: React.FC<MenuItemManagerProps> = ({ restaurantId }) => {
  const { user } = useAuth();
  const { categories, menuItems, addMenuItem, updateMenuItem, deleteMenuItem } = useRestaurantStore();
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingItem, setEditingItem] = useState<MenuItem | null>(null);
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string>('');
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    price: '',
    categoryId: '',
    allergens: '',
    available: true,
    popular: false
  });

  const restaurantCategories = categories.filter(cat => cat.restaurantId === restaurantId);
  const restaurantMenuItems = menuItems.filter(item => item.restaurantId === restaurantId);
  const maxProducts = user?.plan === 'premium' ? Infinity : 20;

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedImage(file);
      const reader = new FileReader();
      reader.onload = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!editingItem && restaurantMenuItems.length >= maxProducts) {
      toast.error(`${user?.plan === 'free' ? 'Ücretsiz planda' : ''} maksimum ${maxProducts} ürün ekleyebilirsiniz!`);
      return;
    }

    const allergensList = formData.allergens
      .split(',')
      .map(a => a.trim())
      .filter(a => a.length > 0);

    if (editingItem) {
      updateMenuItem(editingItem.id, {
        ...formData,
        price: parseFloat(formData.price),
        allergens: allergensList,
        image: imagePreview || editingItem.image
      });
      toast.success('Ürün güncellendi!');
      setEditingItem(null);
    } else {
      addMenuItem({
        ...formData,
        price: parseFloat(formData.price),
        allergens: allergensList,
        restaurantId,
        image: imagePreview
      });
      toast.success('Ürün eklendi!');
    }
    
    resetForm();
  };

  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      price: '',
      categoryId: '',
      allergens: '',
      available: true,
      popular: false
    });
    setSelectedImage(null);
    setImagePreview('');
    setShowAddForm(false);
  };

  const handleEdit = (item: MenuItem) => {
    setEditingItem(item);
    setFormData({
      name: item.name,
      description: item.description,
      price: item.price.toString(),
      categoryId: item.categoryId,
      allergens: item.allergens?.join(', ') || '',
      available: item.available,
      popular: item.popular || false
    });
    setImagePreview(item.image || '');
    setShowAddForm(true);
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Bu ürünü silmek istediğinizden emin misiniz?')) {
      deleteMenuItem(id);
      toast.success('Ürün silindi!');
    }
  };

  const getCategoryName = (categoryId: string) => {
    const category = categories.find(cat => cat.id === categoryId);
    return category?.name || 'Kategori bulunamadı';
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-lg font-semibold text-gray-900">Menü Ürünleri</h3>
          <p className="text-sm text-gray-600">
            {restaurantMenuItems.length} / {maxProducts === Infinity ? '∞' : maxProducts} ürün
          </p>
        </div>
        <button
          onClick={() => setShowAddForm(true)}
          disabled={restaurantMenuItems.length >= maxProducts}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <Plus className="h-4 w-4 mr-2" />
          Ürün Ekle
        </button>
      </div>

      {restaurantCategories.length === 0 && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
          <p className="text-yellow-800">
            Ürün eklemeden önce kategori oluşturmanız gerekiyor.
          </p>
        </div>
      )}

      {/* Add/Edit Form */}
      {showAddForm && restaurantCategories.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gray-50 p-6 rounded-lg border"
        >
          <h4 className="text-md font-semibold text-gray-900 mb-4">
            {editingItem ? 'Ürün Düzenle' : 'Yeni Ürün'}
          </h4>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Ürün Adı *
                </label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Örn: Adana Kebap"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Fiyat (₺) *
                </label>
                <input
                  type="number"
                  step="0.01"
                  required
                  value={formData.price}
                  onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="0.00"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Kategori *
              </label>
              <select
                required
                value={formData.categoryId}
                onChange={(e) => setFormData({ ...formData, categoryId: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">Kategori seçin</option>
                {restaurantCategories.map((category) => (
                  <option key={category.id} value={category.id}>
                    {category.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Açıklama *
              </label>
              <textarea
                required
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                rows={3}
                placeholder="Ürün açıklaması..."
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Ürün Görseli
              </label>
              <div className="flex items-center space-x-4">
                <label className="cursor-pointer bg-gray-100 border-2 border-dashed border-gray-300 rounded-lg p-4 hover:bg-gray-50 transition-colors flex items-center space-x-2">
                  <Upload className="h-5 w-5 text-gray-400" />
                  <span className="text-sm text-gray-600">Görsel Seç</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleImageChange}
                    className="hidden"
                  />
                </label>
                {imagePreview && (
                  <div className="relative">
                    <img
                      src={imagePreview}
                      alt="Preview"
                      className="w-16 h-16 object-cover rounded-lg"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        setImagePreview('');
                        setSelectedImage(null);
                      }}
                      className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs"
                    >
                      ×
                    </button>
                  </div>
                )}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Alerjenler
              </label>
              <input
                type="text"
                value={formData.allergens}
                onChange={(e) => setFormData({ ...formData, allergens: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Örn: Gluten, Süt, Fındık (virgülle ayırın)"
              />
            </div>

            <div className="flex space-x-4">
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={formData.available}
                  onChange={(e) => setFormData({ ...formData, available: e.target.checked })}
                  className="mr-2"
                />
                <span className="text-sm text-gray-700">Mevcut</span>
              </label>
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={formData.popular}
                  onChange={(e) => setFormData({ ...formData, popular: e.target.checked })}
                  className="mr-2"
                />
                <span className="text-sm text-gray-700">Popüler</span>
              </label>
            </div>

            <div className="flex space-x-3">
              <button
                type="submit"
                className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors flex items-center"
              >
                <Save className="h-4 w-4 mr-2" />
                {editingItem ? 'Güncelle' : 'Kaydet'}
              </button>
              <button
                type="button"
                onClick={resetForm}
                className="bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700 transition-colors flex items-center"
              >
                <X className="h-4 w-4 mr-2" />
                İptal
              </button>
            </div>
          </form>
        </motion.div>
      )}

      {/* Menu Items List */}
      <div className="grid gap-4">
        {restaurantMenuItems.map((item) => (
          <motion.div
            key={item.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white p-4 rounded-lg border border-gray-200"
          >
            <div className="flex items-start space-x-4">
              <div className="w-16 h-16 bg-gray-200 rounded-lg flex items-center justify-center flex-shrink-0">
                {item.image ? (
                  <img
                    src={item.image}
                    alt={item.name}
                    className="w-full h-full object-cover rounded-lg"
                  />
                ) : (
                  <ImageIcon className="h-8 w-8 text-gray-400" />
                )}
              </div>
              
              <div className="flex-1">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center space-x-2">
                      <h4 className="font-semibold text-gray-900">{item.name}</h4>
                      {item.popular && (
                        <span className="bg-yellow-100 text-yellow-800 text-xs px-2 py-1 rounded-full">
                          Popüler
                        </span>
                      )}
                      {!item.available && (
                        <span className="bg-red-100 text-red-800 text-xs px-2 py-1 rounded-full">
                          Mevcut Değil
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-gray-600 mt-1">{item.description}</p>
                    <div className="flex items-center space-x-4 mt-2">
                      <span className="text-lg font-bold text-gray-900">₺{item.price}</span>
                      <span className="text-sm bg-blue-100 text-blue-800 px-2 py-1 rounded">
                        {getCategoryName(item.categoryId)}
                      </span>
                    </div>
                    {item.allergens && item.allergens.length > 0 && (
                      <p className="text-xs text-orange-600 mt-1">
                        Alerjenler: {item.allergens.join(', ')}
                      </p>
                    )}
                  </div>
                  
                  <div className="flex space-x-2">
                    <button
                      onClick={() => handleEdit(item)}
                      className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                    >
                      <Edit className="h-4 w-4" />
                    </button>
                    <button
                      onClick={() => handleDelete(item.id)}
                      className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {restaurantMenuItems.length === 0 && restaurantCategories.length > 0 && (
        <div className="text-center py-8 text-gray-500">
          <p>Henüz ürün eklenmemiş.</p>
          <p className="text-sm">İlk ürününüzü ekleyerek başlayın.</p>
        </div>
      )}
    </div>
  );
};

export default MenuItemManager;