import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Save, Bell, Smartphone, CreditCard, Globe, Wifi, Crown } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import toast from 'react-hot-toast';

interface RestaurantSettingsProps {
  restaurantId: string;
}

const RestaurantSettings: React.FC<RestaurantSettingsProps> = ({ restaurantId }) => {
  const { user } = useAuth();
  const [settings, setSettings] = useState({
    waiterCallEnabled: true,
    posIntegrationEnabled: false,
    orderTakingEnabled: false,
    nfcEnabled: true,
    multiLanguageEnabled: false,
    offlineMenuEnabled: false,
    autoAcceptOrders: true,
    soundNotifications: true,
    emailNotifications: true,
    smsNotifications: false
  });

  const handleSave = () => {
    // Ücretsiz plan kısıtlamaları
    if (user?.plan === 'free') {
      const restrictedSettings = {
        ...settings,
        posIntegrationEnabled: false,
        orderTakingEnabled: false,
        multiLanguageEnabled: false,
        offlineMenuEnabled: false,
        smsNotifications: false
      };
      setSettings(restrictedSettings);
      toast.success('Ayarlar kaydedildi! (Ücretsiz plan kısıtlamaları uygulandı)');
    } else {
      toast.success('Ayarlar kaydedildi!');
    }
  };

  const isPremiumFeature = (feature: string) => {
    const premiumFeatures = [
      'posIntegrationEnabled',
      'orderTakingEnabled', 
      'multiLanguageEnabled',
      'offlineMenuEnabled',
      'smsNotifications'
    ];
    return premiumFeatures.includes(feature);
  };

  const SettingItem = ({ 
    id, 
    title, 
    description, 
    icon: Icon, 
    isPremium = false 
  }: {
    id: keyof typeof settings;
    title: string;
    description: string;
    icon: any;
    isPremium?: boolean;
  }) => {
    const isDisabled = isPremium && user?.plan === 'free';
    
    return (
      <div className={`p-4 border rounded-lg ${isDisabled ? 'bg-gray-50 opacity-60' : 'bg-white'}`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Icon className={`h-5 w-5 ${isDisabled ? 'text-gray-400' : 'text-blue-600'}`} />
            <div>
              <div className="flex items-center space-x-2">
                <h4 className="font-medium text-gray-900">{title}</h4>
                {isPremium && (
                  <Crown className="h-4 w-4 text-yellow-500" />
                )}
              </div>
              <p className="text-sm text-gray-600">{description}</p>
            </div>
          </div>
          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={settings[id]}
              onChange={(e) => setSettings({ ...settings, [id]: e.target.checked })}
              disabled={isDisabled}
              className="sr-only peer"
            />
            <div className={`w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600 ${isDisabled ? 'cursor-not-allowed' : ''}`}></div>
          </label>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold text-gray-900">Restoran Ayarları</h3>
        <button
          onClick={handleSave}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center"
        >
          <Save className="h-4 w-4 mr-2" />
          Kaydet
        </button>
      </div>

      {user?.plan === 'free' && (
        <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-semibold text-blue-900">Premium Özellikleri Açın</h4>
              <p className="text-sm text-blue-700">
                Tüm özelliklere erişim için Premium plana geçin
              </p>
            </div>
            <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors">
              Premium'a Geç
            </button>
          </div>
        </div>
      )}

      <div className="space-y-4">
        <div>
          <h4 className="text-md font-semibold text-gray-900 mb-3">Müşteri Etkileşimi</h4>
          <div className="space-y-3">
            <SettingItem
              id="waiterCallEnabled"
              title="Garson Çağırma"
              description="Müşteriler menüden garson çağırabilir"
              icon={Bell}
            />
            <SettingItem
              id="posIntegrationEnabled"
              title="POS Entegrasyonu"
              description="Garson POS cihazı ile gelsin"
              icon={CreditCard}
              isPremium={true}
            />
            <SettingItem
              id="orderTakingEnabled"
              title="Sipariş Alma"
              description="Müşteriler direkt sipariş verebilir"
              icon={Smartphone}
              isPremium={true}
            />
          </div>
        </div>

        <div>
          <h4 className="text-md font-semibold text-gray-900 mb-3">Menü Özellikleri</h4>
          <div className="space-y-3">
            <SettingItem
              id="nfcEnabled"
              title="NFC Desteği"
              description="NFC etiketleri ile menü erişimi"
              icon={Smartphone}
            />
            <SettingItem
              id="multiLanguageEnabled"
              title="Çoklu Dil"
              description="Menü birden fazla dilde gösterilsin"
              icon={Globe}
              isPremium={true}
            />
            <SettingItem
              id="offlineMenuEnabled"
              title="Offline Menü"
              description="İnternet olmadan da menü görüntülensin"
              icon={Wifi}
              isPremium={true}
            />
          </div>
        </div>

        <div>
          <h4 className="text-md font-semibold text-gray-900 mb-3">Bildirimler</h4>
          <div className="space-y-3">
            <SettingItem
              id="soundNotifications"
              title="Ses Bildirimleri"
              description="Yeni sipariş ve çağrılarda ses çalsın"
              icon={Bell}
            />
            <SettingItem
              id="emailNotifications"
              title="Email Bildirimleri"
              description="Önemli olaylar email ile bildirilsin"
              icon={Bell}
            />
            <SettingItem
              id="smsNotifications"
              title="SMS Bildirimleri"
              description="Acil durumlar SMS ile bildirilsin"
              icon={Bell}
              isPremium={true}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default RestaurantSettings;