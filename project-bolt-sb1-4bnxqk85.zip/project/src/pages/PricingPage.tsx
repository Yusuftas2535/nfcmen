import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { CheckCircle, X, Crown, Zap, QrCode } from 'lucide-react';

const PricingPage = () => {
  const plans = [
    {
      name: 'Ücretsiz',
      price: '₺0',
      period: '/ay',
      description: 'Küçük işletmeler için başlangıç paketi',
      features: [
        'Maksimum 20 ürün',
        'Temel QR menü',
        'Mobil uyumlu tasarım',
        'Temel müşteri desteği',
        'NFCMenu logosu ile'
      ],
      limitations: [
        'NFC desteği yok',
        'Garson çağırma yok',
        'Analiz raporları yok',
        'Özelleştirme yok'
      ],
      buttonText: 'Ücretsiz Başla',
      buttonClass: 'border-2 border-gray-300 text-gray-700 hover:bg-gray-50',
      popular: false
    },
    {
      name: 'Premium',
      price: '₺99',
      period: '/ay',
      description: 'Profesyonel işletmeler için tam özellikli paket',
      features: [
        'Sınırsız ürün',
        'QR + NFC menü desteği',
        'Garson çağırma sistemi',
        'Detaylı analiz raporları',
        'Özel tasarım seçenekleri',
        'Çoklu dil desteği',
        'Öncelikli müşteri desteği',
        'Kendi logonuz',
        'Offline menü görüntüleme',
        'Sosyal medya entegrasyonu'
      ],
      limitations: [],
      buttonText: 'Premium\'a Geç',
      buttonClass: 'bg-blue-600 text-white hover:bg-blue-700',
      popular: true
    }
  ];

  const faqs = [
    {
      question: 'Ücretsiz plan ne kadar süre kullanılabilir?',
      answer: 'Ücretsiz plan süresiz kullanılabilir. Ancak 20 ürün limiti ve temel özelliklerle sınırlıdır.'
    },
    {
      question: 'Premium plana geçiş nasıl yapılır?',
      answer: 'Dashboard\'unuzdan "Premium\'a Geç" butonuna tıklayarak kolayca yükseltme yapabilirsiniz.'
    },
    {
      question: 'NFC teknolojisi nasıl çalışır?',
      answer: 'NFC etiketlerini masalarınıza yerleştirirsiniz. Müşteriler telefonlarını etikete yaklaştırarak menüye erişir.'
    },
    {
      question: 'Kurulum ne kadar sürer?',
      answer: 'Kayıt olduktan sonra 5 dakika içinde menünüzü oluşturup QR kodunuzu alabilirsiniz.'
    },
    {
      question: 'Müşteri desteği nasıl sağlanır?',
      answer: 'Ücretsiz planda email desteği, Premium planda 7/24 telefon ve WhatsApp desteği sunuyoruz.'
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <Link to="/" className="flex items-center space-x-2">
              <QrCode className="h-8 w-8 text-blue-600" />
              <span className="text-2xl font-bold text-gray-900">NFCMenu</span>
            </Link>
            <div className="flex items-center space-x-4">
              <Link to="/login" className="text-gray-600 hover:text-blue-600">Giriş</Link>
              <Link 
                to="/register" 
                className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700"
              >
                Kayıt Ol
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-50 to-indigo-100 py-16">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-5xl font-bold text-gray-900 mb-6">
              Size Uygun Planı Seçin
            </h1>
            <p className="text-xl text-gray-600 mb-8">
              İşletmenizin büyüklüğüne göre esnek fiyatlandırma seçenekleri
            </p>
          </motion.div>
        </div>
      </section>

      {/* Pricing Cards */}
      <section className="py-16">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {plans.map((plan, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className={`relative bg-white rounded-2xl shadow-xl p-8 ${
                  plan.popular ? 'ring-2 ring-blue-600 scale-105' : ''
                }`}
              >
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <div className="bg-blue-600 text-white px-6 py-2 rounded-full text-sm font-semibold flex items-center">
                      <Crown className="h-4 w-4 mr-1" />
                      En Popüler
                    </div>
                  </div>
                )}

                <div className="text-center mb-8">
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">{plan.name}</h3>
                  <p className="text-gray-600 mb-4">{plan.description}</p>
                  <div className="flex items-baseline justify-center">
                    <span className="text-5xl font-bold text-gray-900">{plan.price}</span>
                    <span className="text-xl text-gray-600 ml-1">{plan.period}</span>
                  </div>
                </div>

                <div className="space-y-4 mb-8">
                  {plan.features.map((feature, featureIndex) => (
                    <div key={featureIndex} className="flex items-center">
                      <CheckCircle className="h-5 w-5 text-green-500 mr-3 flex-shrink-0" />
                      <span className="text-gray-700">{feature}</span>
                    </div>
                  ))}
                  {plan.limitations.map((limitation, limitIndex) => (
                    <div key={limitIndex} className="flex items-center opacity-50">
                      <X className="h-5 w-5 text-gray-400 mr-3 flex-shrink-0" />
                      <span className="text-gray-500">{limitation}</span>
                    </div>
                  ))}
                </div>

                <Link
                  to="/register"
                  className={`w-full py-4 px-6 rounded-lg font-semibold text-center transition-colors block ${plan.buttonClass}`}
                >
                  {plan.buttonText}
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Comparison */}
      <section className="py-16 bg-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Detaylı Özellik Karşılaştırması
            </h2>
            <p className="text-xl text-gray-600">
              Hangi planın size uygun olduğunu görün
            </p>
          </div>

          <div className="bg-gray-50 rounded-2xl overflow-hidden">
            <div className="grid grid-cols-3 gap-4 p-6 bg-gray-100">
              <div className="font-semibold text-gray-900">Özellik</div>
              <div className="font-semibold text-gray-900 text-center">Ücretsiz</div>
              <div className="font-semibold text-gray-900 text-center">Premium</div>
            </div>
            
            {[
              ['Ürün Sayısı', '20 ürün', 'Sınırsız'],
              ['QR Menü', '✓', '✓'],
              ['NFC Desteği', '✗', '✓'],
              ['Garson Çağırma', '✗', '✓'],
              ['Analiz Raporları', '✗', '✓'],
              ['Özel Tasarım', '✗', '✓'],
              ['Çoklu Dil', '✗', '✓'],
              ['Offline Menü', '✗', '✓'],
              ['Müşteri Desteği', 'Email', '7/24 Telefon'],
              ['Logo Kaldırma', '✗', '✓']
            ].map((row, index) => (
              <div key={index} className={`grid grid-cols-3 gap-4 p-4 ${index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}`}>
                <div className="text-gray-900">{row[0]}</div>
                <div className="text-center text-gray-600">{row[1]}</div>
                <div className="text-center text-gray-600">{row[2]}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Sıkça Sorulan Sorular
            </h2>
            <p className="text-xl text-gray-600">
              Merak ettiğiniz her şey burada
            </p>
          </div>

          <div className="space-y-6">
            {faqs.map((faq, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="bg-white rounded-lg shadow-md p-6"
              >
                <h3 className="text-lg font-semibold text-gray-900 mb-3">
                  {faq.question}
                </h3>
                <p className="text-gray-600 leading-relaxed">
                  {faq.answer}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-blue-600">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-white mb-6">
            Hemen Başlamaya Hazır mısınız?
          </h2>
          <p className="text-xl text-blue-100 mb-8">
            Ücretsiz plan ile başlayın, istediğiniz zaman Premium'a geçin
          </p>
          <Link 
            to="/register"
            className="bg-white text-blue-600 px-8 py-4 rounded-lg text-lg font-semibold hover:bg-gray-100 transition-colors inline-flex items-center"
          >
            <Zap className="mr-2 h-5 w-5" />
            Ücretsiz Hesap Oluştur
          </Link>
        </div>
      </section>
    </div>
  );
};

export default PricingPage;