import React, { createContext, useContext, useState, useEffect } from 'react';

interface User {
  id: string;
  email: string;
  name: string;
  role: 'admin' | 'restaurant' | 'waiter';
  restaurantId?: string;
  plan?: 'free' | 'premium';
  permissions?: WaiterPermissions;
}

interface WaiterPermissions {
  canTakeOrders: boolean;
  canManageTables: boolean;
  canViewReports: boolean;
  canEditMenu: boolean;
}

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<boolean>;
  register: (data: RegisterData) => Promise<boolean>;
  logout: () => void;
  loading: boolean;
}

interface RegisterData {
  email: string;
  password: string;
  name: string;
  restaurantName: string;
  phone: string;
  address: string;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check for stored user session
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
    setLoading(false);
  }, []);

  const login = async (email: string, password: string): Promise<boolean> => {
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Mock login logic
      if (email === 'admin@nfcmenu.com' && password === 'admin123') {
        const adminUser: User = {
          id: 'admin-1',
          email: 'admin@nfcmenu.com',
          name: 'Admin',
          role: 'admin'
        };
        setUser(adminUser);
        localStorage.setItem('user', JSON.stringify(adminUser));
        return true;
      } else if (email === 'garson@test.com' && password === 'garson123') {
        const waiterUser: User = {
          id: 'waiter-1',
          email: 'garson@test.com',
          name: 'Garson Ali',
          role: 'waiter',
          restaurantId: 'rest-1',
          permissions: {
            canTakeOrders: true,
            canManageTables: true,
            canViewReports: false,
            canEditMenu: false
          }
        };
        setUser(waiterUser);
        localStorage.setItem('user', JSON.stringify(waiterUser));
        return true;
      } else if (email && password) {
        const restaurantUser: User = {
          id: 'rest-1',
          email,
          name: 'Restaurant Owner',
          role: 'restaurant',
          restaurantId: 'rest-1',
          plan: 'free'
        };
        setUser(restaurantUser);
        localStorage.setItem('user', JSON.stringify(restaurantUser));
        return true;
      }
      return false;
    } catch (error) {
      return false;
    }
  };

  const register = async (data: RegisterData): Promise<boolean> => {
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const newUser: User = {
        id: `rest-${Date.now()}`,
        email: data.email,
        name: data.name,
        role: 'restaurant',
        restaurantId: `rest-${Date.now()}`,
        plan: 'free'
      };
      
      setUser(newUser);
      localStorage.setItem('user', JSON.stringify(newUser));
      return true;
    } catch (error) {
      return false;
    }
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('user');
  };

  return (
    <AuthContext.Provider value={{ user, login, register, logout, loading }}>
      {children}
    </AuthContext.Provider>
  );
};