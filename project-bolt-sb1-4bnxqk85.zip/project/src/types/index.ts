export interface User {
  id: string;
  email: string;
  name: string;
  role: 'admin' | 'restaurant' | 'waiter';
  restaurantId?: string;
  plan?: 'free' | 'premium';
  permissions?: WaiterPermissions;
}

export interface WaiterPermissions {
  canTakeOrders: boolean;
  canManageTables: boolean;
  canViewReports: boolean;
  canEditMenu: boolean;
}

export interface Restaurant {
  id: string;
  name: string;
  description: string;
  owner: string;
  email: string;
  phone: string;
  address: string;
  plan: 'free' | 'premium';
  status: 'active' | 'inactive' | 'pending';
  createdAt: string;
  settings: RestaurantSettings;
  features: RestaurantFeatures;
}

export interface RestaurantSettings {
  waiterCallEnabled: boolean;
  posIntegrationEnabled: boolean;
  orderTakingEnabled: boolean;
  nfcEnabled: boolean;
  multiLanguageEnabled: boolean;
  offlineMenuEnabled: boolean;
}

export interface RestaurantFeatures {
  maxProducts: number;
  analyticsEnabled: boolean;
  customDesignEnabled: boolean;
  prioritySupportEnabled: boolean;
}

export interface Category {
  id: string;
  name: string;
  description?: string;
  restaurantId: string;
  order: number;
  createdAt: string;
}

export interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: number;
  categoryId: string;
  restaurantId: string;
  image?: string;
  allergens?: string[];
  available: boolean;
  popular?: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Table {
  id: string;
  number: string;
  restaurantId: string;
  capacity: number;
  status: 'available' | 'occupied' | 'reserved' | 'cleaning';
  qrCode?: string;
  nfcId?: string;
  assignedWaiterId?: string;
}

export interface Order {
  id: string;
  restaurantId: string;
  tableId: string;
  waiterId?: string;
  items: OrderItem[];
  status: 'pending' | 'preparing' | 'ready' | 'served' | 'cancelled';
  totalAmount: number;
  createdAt: string;
  updatedAt: string;
  notes?: string;
}

export interface OrderItem {
  id: string;
  menuItemId: string;
  quantity: number;
  price: number;
  notes?: string;
}

export interface WaiterCall {
  id: string;
  restaurantId: string;
  tableId: string;
  type: 'waiter' | 'pos' | 'order';
  status: 'pending' | 'responded' | 'completed';
  createdAt: string;
  respondedAt?: string;
  respondedBy?: string;
  notes?: string;
}