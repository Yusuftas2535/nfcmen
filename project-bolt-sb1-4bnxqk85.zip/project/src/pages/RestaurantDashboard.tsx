import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  QrCode, 
  Plus, 
  Edit, 
  Trash2, 
  Eye, 
  Settings, 
  BarChart3, 
  Users, 
  Crown,
  Download,
  Share2,
  Bell,
  Smartphone,
  TrendingUp,
  DollarSign,
  Clock,
  Star,
  Menu as MenuIcon,
  Table,
  UserPlus
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useRestaurantStore } from '../stores/useRestaurantStore';
import CategoryManager from '../components/CategoryManager';
import MenuItemManager from '../components/MenuItemManager';
import RestaurantSettings from '../components/RestaurantSettings';
import toast from 'react-hot-toast';

const RestaurantDashboard = () => {
  const { user, logout } = useAuth();
  const { menuItems, tables, orders, waiterCalls } = useRestaurantStore();
  const [activeTab, setActiveTab] = useState('overview');

  const restaurantMenuItems = menuItems.filter(item => item.restaurantId === user?.restaurantId);
  const restaurantTables = tables.filter(table => table.restaurantId === user?.restaurantId);
  const restaurantOrders = orders.filter(order => order.restaurantId === user?.restaurantId);
  const pendingCalls = waiterCalls.filter(call => 
    call.restaurantId === user?.restaurantId && call.status === 'pending'
  );

  const stats = [
    { 
      title: 'Toplam Ürün', 
      value: restaurantMenuItems.length, 
      icon: QrCode, 
      color: 'blue',
      limit: user?.plan === 'free' ? 20 : null
    },
    { 
      title: 'Aylık Görüntülenme', 
      value: '1,234', 
      icon: Eye, 
      color: 'green' 
    },
    { 
      title: 'Bekleyen Çağrılar', 
      value: pendingCalls.length, 
      icon: Bell, 
      color: 'yellow' 
    },
    { 
      title: 'Aktif Masalar', 
      value: restaurantTables.filter(t => t.status === 'occupied').length, 
      icon: Table, 
      color: 'purple' 
    }
  ];

  const recentOrders = restaurantOrders.slice(0, 5);

  const generateQRCode = () => {
    const menuUrl = `${window.location.origin}/menu/${user?.restaurantId}`;
    // QR kod oluşturma işlemi burada yapılacak
    toast.success('QR kod oluşturuldu!');
    console.log('QR URL:', menuUrl);
  };

  const shareMenu = () => {
    const menuUrl = `${window.location.origin}/menu/${user?.restaurantId}`;
    navigator.clipboard.writeText(menuUrl);
    toast.success('Menü linki kopyalandı!');
  };

  const renderOverview = () => (
    <div className="space-y-6">
      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-white rounded-xl shadow-sm p-6 border border-gray-100"
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                <div className="flex items-center space-x-2">
                  <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                  {stat.limit && (
                    <span className="text-sm text-gray-500">/ {stat.limit}</span>
                  )}
                </div>
                {stat.limit && stat.value >= stat.limit * 0.8 && (
                  <p className="text-xs text-orange-600 mt-1">Limite yaklaşıyorsunuz</p>
                )}
              </div>
              <div className={`p-3 rounded-lg bg-${stat.color}-100`}>
                <stat.icon className={`h-6 w-6 text-${stat.color}-600`} />
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Quick Actions */}
      <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Hızlı İşlemler</h3>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <button
            onClick={generateQRCode}
            className="flex items-center justify-center p-4 border-2 border-dashed border-blue-300 rounded-lg hover:border-blue-400 hover:bg-blue-50 transition-colors"
          >
            <QrCode className="h-6 w-6 text-blue-600 mr-2" />
            <span className="text-blue-600 font-medium">QR Kod İndir</span>
          </button>
          <button
            onClick={shareMenu}
            className="flex items-center justify-center p-4 border-2 border-dashed border-green-300 rounded-lg hover:border-green-400 hover:bg-green-50 transition-colors"
          >
            <Share2 className="h-6 w-6 text-green-600 mr-2" />
            <span className="text-green-600 font-medium">Menü Paylaş</span>
          </button>
          <button
            onClick={() => setActiveTab('menu')}
            className="flex items-center justify-center p-4 border-2 border-dashed border-purple-300 rounded-lg hover:border-purple-400 hover:bg-purple-50 transition-colors"
          >
            <Plus className="h-6 w-6 text-purple-600 mr-2" />
            <span className="text-purple-600 font-medium">Ürün Ekle</span>
          </button>
          <button
            onClick={() => setActiveTab('waiters')}
            className="flex items-center justify-center p-4 border-2 border-dashed border-orange-300 rounded-lg hover:border-orange-400 hover:bg-orange-50 transition-colors"
          >
            <UserPlus className="h-6 w-6 text-orange-600 mr-2" />
            <span className="text-orange-600 font-medium">Garson Ekle</span>
          </button>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Son Siparişler</h3>
          <div className="space-y-3">
            {recentOrders.length > 0 ? recentOrders.map((order) => (
              <div key={order.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div>
                  <div className="font-medium text-gray-900">Sipariş #{order.id.slice(-4)}</div>
                  <div className="text-sm text-gray-600">{order.items.length} ürün</div>
                </div>
                <div className="text-right">
                  <div className="font-semibold text-gray-900">₺{order.totalAmount}</div>
                  <div className="text-xs text-gray-500">{new Date(order.createdAt).toLocaleTimeString('tr-TR')}</div>
                </div>
              </div>
            )) : (
              <p className="text-gray-500 text-center py-4">Henüz sipariş bulunmuyor</p>
            )}
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Bekleyen Çağrılar</h3>
          <div className="space-y-3">
            {pendingCalls.length > 0 ? pendingCalls.map((call) => (
              <div key={call.id} className="flex items-center justify-between p-3 bg-red-50 rounded-lg">
                <div>
                  <div className="font-medium text-gray-900">
                    {tables.find(t => t.id === call.tableId)?.number}
                  </div>
                  <div className="text-sm text-red-600">
                    {call.type === 'waiter' ? 'Garson Çağrısı' : 
                     call.type === 'pos' ? 'POS Talebi' : 'Sipariş Talebi'}
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-xs text-gray-500">
                    {new Date(call.createdAt).toLocaleTimeString('tr-TR')}
                  </div>
                </div>
              </div>
            )) : (
              <p className="text-gray-500 text-center py-4">Bekleyen çağrı bulunmuyor</p>
            )}
          </div>
        </div>
      </div>

      {/* Plan Upgrade Banner */}
      {user?.plan === 'free' && (
        <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-xl p-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-semibold text-blue-900 mb-2">
                Premium'a Geçin ve Tüm Özellikleri Açın
              </h3>
              <p className="text-blue-700">
                Sınırsız ürün, NFC desteği, garson çağırma sistemi ve daha fazlası...
              </p>
            </div>
            <button className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors flex items-center">
              <Crown className="h-5 w-5 mr-2" />
              Premium'a Geç
            </button>
          </div>
        </div>
      )}
    </div>
  );

  const renderAnalytics = () => (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-900">Analiz & Raporlar</h2>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Popüler Ürünler</h3>
          <div className="space-y-3">
            {restaurantMenuItems.slice(0, 5).map((item, index) => (
              <div key={item.id} className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <span className="text-sm font-medium text-gray-500">#{index + 1}</span>
                  <span className="font-medium text-gray-900">{item.name}</span>
                </div>
                <span className="text-sm text-gray-600">{Math.floor(Math.random() * 50) + 10} sipariş</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Masa Durumları</h3>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-600">Boş Masalar</span>
              <span className="font-semibold text-green-600">
                {restaurantTables.filter(t => t.status === 'available').length}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Dolu Masalar</span>
              <span className="font-semibold text-red-600">
                {restaurantTables.filter(t => t.status === 'occupied').length}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Rezerve Masalar</span>
              <span className="font-semibold text-yellow-600">
                {restaurantTables.filter(t => t.status === 'reserved').length}
              </span>
            </div>
          </div>
        </div>
      </div>

      {user?.plan === 'free' && (
        <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-xl p-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-semibold text-blue-900 mb-2">
                Detaylı Analizler için Premium'a Geçin
              </h3>
              <p className="text-blue-700">
                Müşteri davranış analizleri, gelir raporları ve daha fazlası...
              </p>
            </div>
            <button className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors flex items-center">
              <Crown className="h-5 w-5 mr-2" />
              Premium'a Geç
            </button>
          </div>
        </div>
      )}
    </div>
  );

  const renderWaiters = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900">Garson Yönetimi</h2>
        <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center">
          <UserPlus className="h-4 w-4 mr-2" />
          Garson Ekle
        </button>
      </div>

      <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
        <p className="text-gray-600">Garson yönetimi özelliği geliştiriliyor...</p>
        <div className="mt-4 space-y-2">
          <p className="text-sm text-gray-500">• Garson hesapları oluşturma</p>
          <p className="text-sm text-gray-500">• Masa atama yetkileri</p>
          <p className="text-sm text-gray-500">• Sipariş alma izinleri</p>
          <p className="text-sm text-gray-500">• Performans takibi</p>
        </div>
      </div>
    </div>
  );

  const tabs = [
    { id: 'overview', name: 'Genel Bakış', icon: BarChart3 },
    { id: 'menu', name: 'Menü Yönetimi', icon: MenuIcon },
    { id: 'tables', name: 'Masa Yönetimi', icon: Table },
    { id: 'waiters', name: 'Garson Yönetimi', icon: Users },
    { id: 'analytics', name: 'Analiz', icon: TrendingUp },
    { id: 'settings', name: 'Ayarlar', icon: Settings }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-4">
              <QrCode className="h-8 w-8 text-blue-600" />
              <div>
                <h1 className="text-xl font-bold text-gray-900">NFCMenu Dashboard</h1>
                <p className="text-sm text-gray-600">Hoş geldiniz, {user?.name}</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              {user?.plan === 'free' && (
                <button className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white px-4 py-2 rounded-lg hover:from-blue-700 hover:to-indigo-700 transition-colors flex items-center">
                  <Crown className="h-4 w-4 mr-2" />
                  Premium'a Geç
                </button>
              )}
              <button
                onClick={logout}
                className="text-gray-600 hover:text-gray-900 transition-colors"
              >
                Çıkış
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar */}
          <div className="lg:w-64 flex-shrink-0">
            <nav className="space-y-2">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`w-full flex items-center px-4 py-3 text-left rounded-lg transition-colors ${
                    activeTab === tab.id
                      ? 'bg-blue-100 text-blue-700 border border-blue-200'
                      : 'text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  <tab.icon className="h-5 w-5 mr-3" />
                  {tab.name}
                </button>
              ))}
            </nav>
          </div>

          {/* Main Content */}
          <div className="flex-1">
            {activeTab === 'overview' && renderOverview()}
            {activeTab === 'menu' && (
              <div className="space-y-8">
                <CategoryManager restaurantId={user?.restaurantId || ''} />
                <MenuItemManager restaurantId={user?.restaurantId || ''} />
              </div>
            )}
            {activeTab === 'tables' && (
              <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
                <h2 className="text-2xl font-bold text-gray-900 mb-6">Masa Yönetimi</h2>
                <p className="text-gray-600">Masa yönetimi özelliği geliştiriliyor...</p>
              </div>
            )}
            {activeTab === 'waiters' && renderWaiters()}
            {activeTab === 'analytics' && renderAnalytics()}
            {activeTab === 'settings' && (
              <RestaurantSettings restaurantId={user?.restaurantId || ''} />
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default RestaurantDashboard;