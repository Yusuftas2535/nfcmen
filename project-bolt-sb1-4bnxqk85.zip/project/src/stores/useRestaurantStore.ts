import { create } from 'zustand';
import { Category, MenuItem, Table, Order, WaiterCall } from '../types';

interface RestaurantStore {
  categories: Category[];
  menuItems: MenuItem[];
  tables: Table[];
  orders: Order[];
  waiterCalls: WaiterCall[];
  
  // Categories
  addCategory: (category: Omit<Category, 'id' | 'createdAt'>) => void;
  updateCategory: (id: string, updates: Partial<Category>) => void;
  deleteCategory: (id: string) => void;
  
  // Menu Items
  addMenuItem: (item: Omit<MenuItem, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateMenuItem: (id: string, updates: Partial<MenuItem>) => void;
  deleteMenuItem: (id: string) => void;
  
  // Tables
  addTable: (table: Omit<Table, 'id'>) => void;
  updateTable: (id: string, updates: Partial<Table>) => void;
  deleteTable: (id: string) => void;
  
  // Orders
  addOrder: (order: Omit<Order, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateOrder: (id: string, updates: Partial<Order>) => void;
  
  // Waiter Calls
  addWaiterCall: (call: Omit<WaiterCall, 'id' | 'createdAt'>) => void;
  updateWaiterCall: (id: string, updates: Partial<WaiterCall>) => void;
}

export const useRestaurantStore = create<RestaurantStore>((set) => ({
  categories: [
    {
      id: '1',
      name: 'Ana Yemekler',
      description: 'Doyurucu ana yemekler',
      restaurantId: 'rest-1',
      order: 1,
      createdAt: new Date().toISOString()
    },
    {
      id: '2',
      name: 'Çorbalar',
      description: 'Sıcak çorbalar',
      restaurantId: 'rest-1',
      order: 2,
      createdAt: new Date().toISOString()
    },
    {
      id: '3',
      name: 'Tatlılar',
      description: 'Lezzetli tatlılar',
      restaurantId: 'rest-1',
      order: 3,
      createdAt: new Date().toISOString()
    }
  ],
  
  menuItems: [
    {
      id: '1',
      name: 'Adana Kebap',
      description: 'Özel baharatlarla hazırlanmış lezzetli Adana kebap, pilav ve salata ile',
      price: 45,
      categoryId: '1',
      restaurantId: 'rest-1',
      allergens: ['Gluten'],
      available: true,
      popular: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    },
    {
      id: '2',
      name: 'Mercimek Çorbası',
      description: 'Geleneksel mercimek çorbası, taze nane ve limon ile',
      price: 15,
      categoryId: '2',
      restaurantId: 'rest-1',
      allergens: [],
      available: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }
  ],
  
  tables: [
    {
      id: '1',
      number: 'Masa 1',
      restaurantId: 'rest-1',
      capacity: 4,
      status: 'available',
      qrCode: 'QR_TABLE_1'
    },
    {
      id: '2',
      number: 'Masa 2',
      restaurantId: 'rest-1',
      capacity: 2,
      status: 'occupied',
      qrCode: 'QR_TABLE_2'
    }
  ],
  
  orders: [],
  waiterCalls: [],
  
  // Categories
  addCategory: (category) => set((state) => ({
    categories: [...state.categories, {
      ...category,
      id: Date.now().toString(),
      createdAt: new Date().toISOString()
    }]
  })),
  
  updateCategory: (id, updates) => set((state) => ({
    categories: state.categories.map(cat => 
      cat.id === id ? { ...cat, ...updates } : cat
    )
  })),
  
  deleteCategory: (id) => set((state) => ({
    categories: state.categories.filter(cat => cat.id !== id),
    menuItems: state.menuItems.filter(item => item.categoryId !== id)
  })),
  
  // Menu Items
  addMenuItem: (item) => set((state) => ({
    menuItems: [...state.menuItems, {
      ...item,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }]
  })),
  
  updateMenuItem: (id, updates) => set((state) => ({
    menuItems: state.menuItems.map(item => 
      item.id === id ? { ...item, ...updates, updatedAt: new Date().toISOString() } : item
    )
  })),
  
  deleteMenuItem: (id) => set((state) => ({
    menuItems: state.menuItems.filter(item => item.id !== id)
  })),
  
  // Tables
  addTable: (table) => set((state) => ({
    tables: [...state.tables, {
      ...table,
      id: Date.now().toString()
    }]
  })),
  
  updateTable: (id, updates) => set((state) => ({
    tables: state.tables.map(table => 
      table.id === id ? { ...table, ...updates } : table
    )
  })),
  
  deleteTable: (id) => set((state) => ({
    tables: state.tables.filter(table => table.id !== id)
  })),
  
  // Orders
  addOrder: (order) => set((state) => ({
    orders: [...state.orders, {
      ...order,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }]
  })),
  
  updateOrder: (id, updates) => set((state) => ({
    orders: state.orders.map(order => 
      order.id === id ? { ...order, ...updates, updatedAt: new Date().toISOString() } : order
    )
  })),
  
  // Waiter Calls
  addWaiterCall: (call) => set((state) => ({
    waiterCalls: [...state.waiterCalls, {
      ...call,
      id: Date.now().toString(),
      createdAt: new Date().toISOString()
    }]
  })),
  
  updateWaiterCall: (id, updates) => set((state) => ({
    waiterCalls: state.waiterCalls.map(call => 
      call.id === id ? { ...call, ...updates } : call
    )
  }))
}));