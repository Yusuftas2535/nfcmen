import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Bell, 
  Users, 
  ClipboardList, 
  CheckCircle, 
  Clock, 
  AlertCircle,
  Plus,
  Edit,
  Trash2,
  Phone,
  MessageSquare
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useRestaurantStore } from '../stores/useRestaurantStore';
import toast from 'react-hot-toast';

const WaiterDashboard = () => {
  const { user, logout } = useAuth();
  const { tables, orders, waiterCalls, updateTable, addOrder, updateWaiterCall } = useRestaurantStore();
  const [activeTab, setActiveTab] = useState('calls');

  const pendingCalls = waiterCalls.filter(call => call.status === 'pending');
  const myTables = tables.filter(table => table.assignedWaiterId === user?.id);
  const activeOrders = orders.filter(order => 
    ['pending', 'preparing'].includes(order.status) && 
    myTables.some(table => table.id === order.tableId)
  );

  const handleRespondToCall = (callId: string) => {
    updateWaiterCall(callId, {
      status: 'responded',
      respondedAt: new Date().toISOString(),
      respondedBy: user?.id
    });
    toast.success('Çağrıya yanıt verildi!');
  };

  const handleCompleteCall = (callId: string) => {
    updateWaiterCall(callId, {
      status: 'completed'
    });
    toast.success('Çağrı tamamlandı!');
  };

  const handleTableStatusChange = (tableId: string, status: 'available' | 'occupied' | 'reserved' | 'cleaning') => {
    updateTable(tableId, { status });
    toast.success('Masa durumu güncellendi!');
  };

  const getCallTypeText = (type: string) => {
    switch (type) {
      case 'waiter': return 'Garson Çağrısı';
      case 'pos': return 'POS Talebi';
      case 'order': return 'Sipariş Talebi';
      default: return 'Bilinmeyen';
    }
  };

  const getCallTypeIcon = (type: string) => {
    switch (type) {
      case 'waiter': return Bell;
      case 'pos': return ClipboardList;
      case 'order': return Users;
      default: return AlertCircle;
    }
  };

  const renderCalls = () => (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-gray-900">
        Bekleyen Çağrılar ({pendingCalls.length})
      </h3>
      
      {pendingCalls.length === 0 ? (
        <div className="text-center py-8 text-gray-500">
          <Bell className="h-12 w-12 mx-auto mb-4 text-gray-300" />
          <p>Bekleyen çağrı bulunmuyor</p>
        </div>
      ) : (
        <div className="space-y-3">
          {pendingCalls.map((call) => {
            const CallIcon = getCallTypeIcon(call.type);
            const table = tables.find(t => t.id === call.tableId);
            
            return (
              <motion.div
                key={call.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className="bg-white p-4 rounded-lg border-l-4 border-red-500 shadow-sm"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <CallIcon className="h-6 w-6 text-red-600" />
                    <div>
                      <h4 className="font-semibold text-gray-900">
                        {table?.number} - {getCallTypeText(call.type)}
                      </h4>
                      <p className="text-sm text-gray-600">
                        {new Date(call.createdAt).toLocaleTimeString('tr-TR')}
                      </p>
                      {call.notes && (
                        <p className="text-sm text-gray-700 mt-1">{call.notes}</p>
                      )}
                    </div>
                  </div>
                  <div className="flex space-x-2">
                    <button
                      onClick={() => handleRespondToCall(call.id)}
                      className="bg-blue-600 text-white px-3 py-1 rounded text-sm hover:bg-blue-700 transition-colors"
                    >
                      Yanıtla
                    </button>
                    <button
                      onClick={() => handleCompleteCall(call.id)}
                      className="bg-green-600 text-white px-3 py-1 rounded text-sm hover:bg-green-700 transition-colors"
                    >
                      Tamamla
                    </button>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );

  const renderTables = () => (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-gray-900">
        Masalarım ({myTables.length})
      </h3>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {myTables.map((table) => (
          <motion.div
            key={table.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white p-4 rounded-lg border border-gray-200 shadow-sm"
          >
            <div className="flex items-center justify-between mb-3">
              <h4 className="font-semibold text-gray-900">{table.number}</h4>
              <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                table.status === 'available' ? 'bg-green-100 text-green-800' :
                table.status === 'occupied' ? 'bg-red-100 text-red-800' :
                table.status === 'reserved' ? 'bg-yellow-100 text-yellow-800' :
                'bg-gray-100 text-gray-800'
              }`}>
                {table.status === 'available' ? 'Boş' :
                 table.status === 'occupied' ? 'Dolu' :
                 table.status === 'reserved' ? 'Rezerve' : 'Temizleniyor'}
              </span>
            </div>
            
            <p className="text-sm text-gray-600 mb-3">
              Kapasite: {table.capacity} kişi
            </p>
            
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => handleTableStatusChange(table.id, 'available')}
                className="bg-green-100 text-green-800 px-2 py-1 rounded text-xs hover:bg-green-200 transition-colors"
              >
                Boş
              </button>
              <button
                onClick={() => handleTableStatusChange(table.id, 'occupied')}
                className="bg-red-100 text-red-800 px-2 py-1 rounded text-xs hover:bg-red-200 transition-colors"
              >
                Dolu
              </button>
              <button
                onClick={() => handleTableStatusChange(table.id, 'reserved')}
                className="bg-yellow-100 text-yellow-800 px-2 py-1 rounded text-xs hover:bg-yellow-200 transition-colors"
              >
                Rezerve
              </button>
              <button
                onClick={() => handleTableStatusChange(table.id, 'cleaning')}
                className="bg-gray-100 text-gray-800 px-2 py-1 rounded text-xs hover:bg-gray-200 transition-colors"
              >
                Temizlik
              </button>
            </div>
          </motion.div>
        ))}
      </div>
      
      {myTables.length === 0 && (
        <div className="text-center py-8 text-gray-500">
          <Users className="h-12 w-12 mx-auto mb-4 text-gray-300" />
          <p>Size atanmış masa bulunmuyor</p>
        </div>
      )}
    </div>
  );

  const renderOrders = () => (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-gray-900">
        Aktif Siparişler ({activeOrders.length})
      </h3>
      
      {activeOrders.length === 0 ? (
        <div className="text-center py-8 text-gray-500">
          <ClipboardList className="h-12 w-12 mx-auto mb-4 text-gray-300" />
          <p>Aktif sipariş bulunmuyor</p>
        </div>
      ) : (
        <div className="space-y-3">
          {activeOrders.map((order) => {
            const table = tables.find(t => t.id === order.tableId);
            
            return (
              <motion.div
                key={order.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-white p-4 rounded-lg border border-gray-200 shadow-sm"
              >
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <h4 className="font-semibold text-gray-900">
                      {table?.number} - Sipariş #{order.id.slice(-4)}
                    </h4>
                    <p className="text-sm text-gray-600">
                      {new Date(order.createdAt).toLocaleTimeString('tr-TR')}
                    </p>
                  </div>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                    order.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                    order.status === 'preparing' ? 'bg-blue-100 text-blue-800' :
                    'bg-green-100 text-green-800'
                  }`}>
                    {order.status === 'pending' ? 'Bekliyor' :
                     order.status === 'preparing' ? 'Hazırlanıyor' : 'Hazır'}
                  </span>
                </div>
                
                <div className="space-y-1 mb-3">
                  {order.items.map((item, index) => (
                    <div key={index} className="flex justify-between text-sm">
                      <span>{item.quantity}x Ürün #{item.menuItemId.slice(-4)}</span>
                      <span>₺{(item.price * item.quantity).toFixed(2)}</span>
                    </div>
                  ))}
                </div>
                
                <div className="flex justify-between items-center">
                  <span className="font-semibold">Toplam: ₺{order.totalAmount.toFixed(2)}</span>
                  <div className="flex space-x-2">
                    <button className="bg-blue-600 text-white px-3 py-1 rounded text-sm hover:bg-blue-700 transition-colors">
                      Detay
                    </button>
                    <button className="bg-green-600 text-white px-3 py-1 rounded text-sm hover:bg-green-700 transition-colors">
                      Tamamla
                    </button>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );

  const tabs = [
    { id: 'calls', name: 'Çağrılar', icon: Bell, count: pendingCalls.length },
    { id: 'tables', name: 'Masalar', icon: Users, count: myTables.length },
    { id: 'orders', name: 'Siparişler', icon: ClipboardList, count: activeOrders.length }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-4">
              <Bell className="h-8 w-8 text-blue-600" />
              <div>
                <h1 className="text-xl font-bold text-gray-900">Garson Paneli</h1>
                <p className="text-sm text-gray-600">Hoş geldiniz, {user?.name}</p>
              </div>
            </div>
            <button
              onClick={logout}
              className="text-gray-600 hover:text-gray-900 transition-colors"
            >
              Çıkış
            </button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar */}
          <div className="lg:w-64 flex-shrink-0">
            <nav className="space-y-2">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`w-full flex items-center justify-between px-4 py-3 text-left rounded-lg transition-colors ${
                    activeTab === tab.id
                      ? 'bg-blue-100 text-blue-700 border border-blue-200'
                      : 'text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  <div className="flex items-center">
                    <tab.icon className="h-5 w-5 mr-3" />
                    {tab.name}
                  </div>
                  {tab.count > 0 && (
                    <span className="bg-red-500 text-white text-xs px-2 py-1 rounded-full">
                      {tab.count}
                    </span>
                  )}
                </button>
              ))}
            </nav>
          </div>

          {/* Main Content */}
          <div className="flex-1">
            {activeTab === 'calls' && renderCalls()}
            {activeTab === 'tables' && renderTables()}
            {activeTab === 'orders' && renderOrders()}
          </div>
        </div>
      </div>
    </div>
  );
};

export default WaiterDashboard;