import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Users, 
  Building, 
  DollarSign, 
  TrendingUp, 
  Crown, 
  Settings,
  Eye,
  Edit,
  Trash2,
  CheckCircle,
  XCircle,
  Search,
  Filter,
  Download,
  BarChart3,
  UserCheck,
  UserX,
  CreditCard,
  Calendar,
  AlertTriangle,
  Globe
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

interface Restaurant {
  id: string;
  name: string;
  owner: string;
  email: string;
  phone: string;
  plan: 'free' | 'premium';
  status: 'active' | 'inactive' | 'pending';
  createdAt: string;
  menuItems: number;
  monthlyViews: number;
  monthlyRevenue: number;
  lastLogin: string;
  address: string;
}

const AdminDashboard = () => {
  const { logout } = useAuth();
  const [activeTab, setActiveTab] = useState('overview');
  const [searchTerm, setSearchTerm] = useState('');
  const [filterPlan, setFilterPlan] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');

  const [restaurants] = useState<Restaurant[]>([
    {
      id: '1',
      name: 'Lezzet Durağı',
      owner: 'Ahmet Yılmaz',
      email: 'ahmet@lezzetduragi.com',
      phone: '0555 123 45 67',
      plan: 'premium',
      status: 'active',
      createdAt: '2024-01-15',
      menuItems: 45,
      monthlyViews: 2340,
      monthlyRevenue: 99,
      lastLogin: '2024-03-15T10:30:00',
      address: 'İstanbul, Kadıköy'
    },
    {
      id: '2',
      name: 'Cafe Nostaljia',
      owner: 'Fatma Demir',
      email: 'fatma@cafenostaljia.com',
      phone: '0555 987 65 43',
      plan: 'free',
      status: 'active',
      createdAt: '2024-02-20',
      menuItems: 18,
      monthlyViews: 890,
      monthlyRevenue: 0,
      lastLogin: '2024-03-14T15:45:00',
      address: 'Ankara, Çankaya'
    },
    {
      id: '3',
      name: 'Burger House',
      owner: 'Mehmet Kaya',
      email: 'mehmet@burgerhouse.com',
      phone: '0555 456 78 90',
      plan: 'premium',
      status: 'pending',
      createdAt: '2024-03-10',
      menuItems: 32,
      monthlyViews: 1560,
      monthlyRevenue: 99,
      lastLogin: '2024-03-13T09:15:00',
      address: 'İzmir, Konak'
    },
    {
      id: '4',
      name: 'Pizza Corner',
      owner: 'Ayşe Özkan',
      email: 'ayse@pizzacorner.com',
      phone: '0555 789 01 23',
      plan: 'free',
      status: 'inactive',
      createdAt: '2024-01-05',
      menuItems: 12,
      monthlyViews: 234,
      monthlyRevenue: 0,
      lastLogin: '2024-02-28T14:20:00',
      address: 'Bursa, Osmangazi'
    }
  ]);

  const totalRevenue = restaurants.reduce((sum, r) => sum + r.monthlyRevenue, 0);
  const premiumCount = restaurants.filter(r => r.plan === 'premium').length;
  const activeCount = restaurants.filter(r => r.status === 'active').length;
  const pendingCount = restaurants.filter(r => r.status === 'pending').length;

  const stats = [
    {
      title: 'Toplam Restoran',
      value: restaurants.length.toString(),
      change: '+12%',
      icon: Building,
      color: 'blue'
    },
    {
      title: 'Premium Üyeler',
      value: premiumCount.toString(),
      change: '+8%',
      icon: Crown,
      color: 'yellow'
    },
    {
      title: 'Aylık Gelir',
      value: '₺' + totalRevenue.toLocaleString(),
      change: '+15%',
      icon: DollarSign,
      color: 'green'
    },
    {
      title: 'Toplam Görüntülenme',
      value: restaurants.reduce((sum, r) => sum + r.monthlyViews, 0).toLocaleString(),
      change: '+23%',
      icon: Eye,
      color: 'purple'
    }
  ];

  const filteredRestaurants = restaurants.filter(restaurant => {
    const matchesSearch = restaurant.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         restaurant.owner.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         restaurant.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesPlan = filterPlan === 'all' || restaurant.plan === filterPlan;
    const matchesStatus = filterStatus === 'all' || restaurant.status === filterStatus;
    return matchesSearch && matchesPlan && matchesStatus;
  });

  const handleStatusChange = (restaurantId: string, newStatus: 'active' | 'inactive' | 'pending') => {
    console.log(`Changing status of ${restaurantId} to ${newStatus}`);
    // Burada API çağrısı yapılacak
  };

  const handlePlanChange = (restaurantId: string, newPlan: 'free' | 'premium') => {
    console.log(`Changing plan of ${restaurantId} to ${newPlan}`);
    // Burada API çağrısı yapılacak
  };

  const handleDeleteRestaurant = (restaurantId: string) => {
    if (window.confirm('Bu restoranı silmek istediğinizden emin misiniz?')) {
      console.log(`Deleting restaurant ${restaurantId}`);
      // Burada API çağrısı yapılacak
    }
  };

  const renderOverview = () => (
    <div className="space-y-6">
      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-white rounded-xl shadow-sm p-6 border border-gray-100"
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                <p className="text-sm text-green-600 font-medium">{stat.change}</p>
              </div>
              <div className={`p-3 rounded-lg bg-${stat.color}-100`}>
                <stat.icon className={`h-6 w-6 text-${stat.color}-600`} />
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Plan Dağılımı</h3>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <div className="w-4 h-4 bg-yellow-400 rounded mr-3"></div>
                <span className="text-gray-700">Premium</span>
              </div>
              <span className="font-semibold text-gray-900">{premiumCount}</span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <div className="w-4 h-4 bg-gray-400 rounded mr-3"></div>
                <span className="text-gray-700">Ücretsiz</span>
              </div>
              <span className="font-semibold text-gray-900">
                {restaurants.length - premiumCount}
              </span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Durum Dağılımı</h3>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-600">Aktif</span>
              <span className="font-semibold text-green-600">{activeCount}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Beklemede</span>
              <span className="font-semibold text-yellow-600">{pendingCount}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Pasif</span>
              <span className="font-semibold text-red-600">
                {restaurants.length - activeCount - pendingCount}
              </span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Gelir Analizi</h3>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-600">Bu Ay</span>
              <span className="font-semibold text-gray-900">₺{totalRevenue.toLocaleString()}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Ortalama/Restoran</span>
              <span className="font-semibold text-gray-900">
                ₺{premiumCount > 0 ? Math.round(totalRevenue / premiumCount) : 0}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Yıllık Tahmini</span>
              <span className="font-semibold text-green-600">
                ₺{(totalRevenue * 12).toLocaleString()}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Son Kayıtlar</h3>
        <div className="space-y-3">
          {restaurants
            .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
            .slice(0, 5)
            .map((restaurant) => (
            <div key={restaurant.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center space-x-3">
                <div className={`w-3 h-3 rounded-full ${
                  restaurant.status === 'active' ? 'bg-green-500' :
                  restaurant.status === 'pending' ? 'bg-yellow-500' : 'bg-red-500'
                }`}></div>
                <div>
                  <div className="font-medium text-gray-900">{restaurant.name}</div>
                  <div className="text-sm text-gray-600">{restaurant.owner} - {restaurant.address}</div>
                </div>
              </div>
              <div className="text-right">
                <div className={`text-xs px-2 py-1 rounded-full ${
                  restaurant.plan === 'premium' 
                    ? 'bg-yellow-100 text-yellow-800' 
                    : 'bg-gray-100 text-gray-800'
                }`}>
                  {restaurant.plan === 'premium' ? 'Premium' : 'Ücretsiz'}
                </div>
                <div className="text-xs text-gray-500 mt-1">
                  {new Date(restaurant.createdAt).toLocaleDateString('tr-TR')}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderRestaurants = () => (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h2 className="text-2xl font-bold text-gray-900">Restoran Yönetimi</h2>
        <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <input
              type="text"
              placeholder="Restoran ara..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <select
            value={filterPlan}
            onChange={(e) => setFilterPlan(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="all">Tüm Planlar</option>
            <option value="free">Ücretsiz</option>
            <option value="premium">Premium</option>
          </select>
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="all">Tüm Durumlar</option>
            <option value="active">Aktif</option>
            <option value="pending">Beklemede</option>
            <option value="inactive">Pasif</option>
          </select>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Restoran
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Plan
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Durum
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  İstatistikler
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Son Giriş
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  İşlemler
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredRestaurants.map((restaurant) => (
                <tr key={restaurant.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div>
                      <div className="text-sm font-medium text-gray-900">{restaurant.name}</div>
                      <div className="text-sm text-gray-500">{restaurant.owner}</div>
                      <div className="text-sm text-gray-500">{restaurant.email}</div>
                      <div className="text-sm text-gray-500">{restaurant.address}</div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                      restaurant.plan === 'premium'
                        ? 'bg-yellow-100 text-yellow-800'
                        : 'bg-gray-100 text-gray-800'
                    }`}>
                      {restaurant.plan === 'premium' ? 'Premium' : 'Ücretsiz'}
                    </span>
                    {restaurant.plan === 'premium' && (
                      <div className="text-xs text-gray-500 mt-1">₺{restaurant.monthlyRevenue}/ay</div>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                      restaurant.status === 'active'
                        ? 'bg-green-100 text-green-800'
                        : restaurant.status === 'pending'
                        ? 'bg-yellow-100 text-yellow-800'
                        : 'bg-red-100 text-red-800'
                    }`}>
                      {restaurant.status === 'active' ? 'Aktif' : 
                       restaurant.status === 'pending' ? 'Beklemede' : 'Pasif'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    <div>{restaurant.menuItems} ürün</div>
                    <div className="text-gray-500">{restaurant.monthlyViews.toLocaleString()} görüntülenme</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {new Date(restaurant.lastLogin).toLocaleDateString('tr-TR')}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                    <div className="flex space-x-2">
                      <button 
                        className="text-blue-600 hover:text-blue-900"
                        title="Detayları Görüntüle"
                      >
                        <Eye className="h-4 w-4" />
                      </button>
                      <button 
                        className="text-green-600 hover:text-green-900"
                        title="Düzenle"
                      >
                        <Edit className="h-4 w-4" />
                      </button>
                      {restaurant.status === 'pending' && (
                        <>
                          <button 
                            onClick={() => handleStatusChange(restaurant.id, 'active')}
                            className="text-green-600 hover:text-green-900"
                            title="Onayla"
                          >
                            <CheckCircle className="h-4 w-4" />
                          </button>
                          <button 
                            onClick={() => handleStatusChange(restaurant.id, 'inactive')}
                            className="text-red-600 hover:text-red-900"
                            title="Reddet"
                          >
                            <XCircle className="h-4 w-4" />
                          </button>
                        </>
                      )}
                      <button 
                        onClick={() => handleDeleteRestaurant(restaurant.id)}
                        className="text-red-600 hover:text-red-900"
                        title="Sil"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {filteredRestaurants.length === 0 && (
        <div className="text-center py-8 text-gray-500">
          <Building className="h-12 w-12 mx-auto mb-4 text-gray-300" />
          <p>Arama kriterlerinize uygun restoran bulunamadı.</p>
        </div>
      )}
    </div>
  );

  const renderAnalytics = () => (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-900">Sistem Analizleri</h2>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Aylık Gelir Trendi</h3>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-600">Ocak 2024</span>
              <span className="font-semibold text-gray-900">₺{Math.round(totalRevenue * 0.8).toLocaleString()}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Şubat 2024</span>
              <span className="font-semibold text-gray-900">₺{Math.round(totalRevenue * 0.9).toLocaleString()}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Mart 2024</span>
              <span className="font-semibold text-green-600">₺{totalRevenue.toLocaleString()}</span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Kullanım İstatistikleri</h3>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-600">Toplam Menü Görüntüleme</span>
              <span className="font-semibold text-gray-900">
                {restaurants.reduce((sum, r) => sum + r.monthlyViews, 0).toLocaleString()}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Ortalama Ürün/Restoran</span>
              <span className="font-semibold text-gray-900">
                {Math.round(restaurants.reduce((sum, r) => sum + r.menuItems, 0) / restaurants.length)}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Aktif Kullanıcı Oranı</span>
              <span className="font-semibold text-green-600">
                %{Math.round((activeCount / restaurants.length) * 100)}
              </span>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Şehir Dağılımı</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {['İstanbul', 'Ankara', 'İzmir', 'Bursa'].map((city, index) => (
            <div key={city} className="text-center p-4 bg-gray-50 rounded-lg">
              <div className="text-2xl font-bold text-gray-900">
                {restaurants.filter(r => r.address.includes(city)).length}
              </div>
              <div className="text-sm text-gray-600">{city}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderSettings = () => (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-900">Sistem Ayarları</h2>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Platform Ayarları</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-medium text-gray-900">Yeni Kayıt Onayı</h4>
                <p className="text-sm text-gray-600">Yeni restoranlar manuel onay gerektirsin</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" defaultChecked className="sr-only peer" />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
              </label>
            </div>
            
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-medium text-gray-900">Email Bildirimleri</h4>
                <p className="text-sm text-gray-600">Yeni kayıtlar için email bildirimi</p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" defaultChecked className="sr-only peer" />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
              </label>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Fiyatlandırma</h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Premium Plan Fiyatı (₺/ay)
              </label>
              <input
                type="number"
                defaultValue="99"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Ücretsiz Plan Ürün Limiti
              </label>
              <input
                type="number"
                defaultValue="20"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm p-6 border border-gray-100">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Sistem Bakımı</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center">
            <Download className="h-4 w-4 mr-2" />
            Veritabanı Yedeği
          </button>
          <button className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors flex items-center justify-center">
            <BarChart3 className="h-4 w-4 mr-2" />
            Rapor Oluştur
          </button>
          <button className="bg-orange-600 text-white px-4 py-2 rounded-lg hover:bg-orange-700 transition-colors flex items-center justify-center">
            <AlertTriangle className="h-4 w-4 mr-2" />
            Sistem Temizliği
          </button>
        </div>
      </div>
    </div>
  );

  const tabs = [
    { id: 'overview', name: 'Genel Bakış', icon: BarChart3 },
    { id: 'restaurants', name: 'Restoranlar', icon: Building },
    { id: 'analytics', name: 'Analiz', icon: TrendingUp },
    { id: 'settings', name: 'Ayarlar', icon: Settings }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-4">
              <Settings className="h-8 w-8 text-blue-600" />
              <div>
                <h1 className="text-xl font-bold text-gray-900">Admin Panel</h1>
                <p className="text-sm text-gray-600">NFCMenu Yönetim Sistemi</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-right">
                <div className="text-sm font-medium text-gray-900">Sistem Durumu</div>
                <div className="text-xs text-green-600">Çevrimiçi</div>
              </div>
              <button
                onClick={logout}
                className="text-gray-600 hover:text-gray-900 transition-colors"
              >
                Çıkış
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar */}
          <div className="lg:w-64 flex-shrink-0">
            <nav className="space-y-2">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`w-full flex items-center px-4 py-3 text-left rounded-lg transition-colors ${
                    activeTab === tab.id
                      ? 'bg-blue-100 text-blue-700 border border-blue-200'
                      : 'text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  <tab.icon className="h-5 w-5 mr-3" />
                  {tab.name}
                </button>
              ))}
            </nav>
          </div>

          {/* Main Content */}
          <div className="flex-1">
            {activeTab === 'overview' && renderOverview()}
            {activeTab === 'restaurants' && renderRestaurants()}
            {activeTab === 'analytics' && renderAnalytics()}
            {activeTab === 'settings' && renderSettings()}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;